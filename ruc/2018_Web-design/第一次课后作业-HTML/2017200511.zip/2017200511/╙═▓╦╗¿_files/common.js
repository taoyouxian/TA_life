 //��ʼ����
 $("#cazao2").click(function(){						  
	var hotword=$("#key_word").val();
	var leixing=$(".leixing").find("option:selected").val();//.text();
	if (hotword != ""){
		if(leixing=="�㽭"){ window.open("http://search.news.chinanews.com/search.do?q="+encodeURIComponent(hotword)+"&dbtype=zj");  }
		else if(leixing=="����"){window.open("http://sou.chinanews.com.cn/search.do?q="+encodeURIComponent(hotword));}
		else if(leixing=="�ٶ�"){window.open("http://news.baidu.com/ns?cl=2&rn=20&tn=news&word="+encodeURIComponent(hotword)+"&ct=0"); }
 }
	 })

//���Ͷ��
function faa(url, wid, hei, zwid) {
    var flashgg = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="' + wid + '" height="' + hei + '" title="flash"><param name="movie" value="' + url + '" /><param name="quality" value="high" /><param name="SCALE" value="exactfit" /><embed src="' + url + '" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="' + wid + '" height="' + hei + '" scale="exactfit"></embed></object>';
	var flashid=document.getElementById(zwid);
	if(flashid){
    flashid.innerHTML = flashgg;
	}
}
function ggimg(sr, url, wih, hei, zwid,alt,c) {
    var imggg = '<div><a href="' + url + '" target="_blank" class="'+c+'" ><img src="' + sr + '" width="' + wih + '" height="' + hei + '"  alt="'+alt+'" border="0" /></a></div>';
	var ganggaoid=document.getElementById(zwid);
	if(ganggaoid){
    ganggaoid.innerHTML = imggg;
	}
}
function ggimgv2(sr, url, wih, hei, zwid,alt,c) {
    var imggg = '<span><a href="' + url + '" target="_blank" class="'+c+'" ><img src="' + sr + '" width="' + wih + '" height="' + hei + '"  alt="'+alt+'" border="0" /></a></span>';
	var ganggaoid=document.getElementById(zwid);
	if(ganggaoid){
    ganggaoid.innerHTML = imggg;
	}
}
function ggimgv3(sr, zwid) {
    var imggg = '<span>'+sr+'</span>';
	var ganggaoid=document.getElementById(zwid);
	if(ganggaoid){
    ganggaoid.innerHTML = imggg;
	}
}
//����ͷ���滻
function qtheader(){
	var qthurl = "/zj/common/qtheadercommon.html";
	$.ajax({
          async :true,
		  url: qthurl,
		  type: "get",
		  data: { "cid": "7000"},  
		//  dataType : "json", //�����Ѿ��������ݸ�ʽ
	      contentType: "application/x-www-form-urlencoded; charset=gb2312", 
		  success:function(data) {
		          $(".head").html(data);
			  
		   }
		});
}
//ͼƬ��ʾ
$('.showpic').click(function(){
	var showpicurl = $(this).attr('data_url');
	var title = $(this).attr('data_title');
		$(".showpicurl").attr("src",showpicurl);
 		$('.theme-popover-mask').fadeIn(100);
		$('.qrcodeBox').slideDown(200);
});
$('.closeBox .close').click(function(){
		$('.theme-popover-mask').fadeOut(100);
		$('.qrcodeBox').slideUp(200);
});